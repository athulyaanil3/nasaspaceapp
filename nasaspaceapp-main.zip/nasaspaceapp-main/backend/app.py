from flask import Flask, request, jsonify,render_template
import requests
from dateutil import parser
import datetime
import statistics

app = Flask(__name__, template_folder="../templates", static_folder="../static")


POWER_BASE = "https://power.larc.nasa.gov/api/temporal/daily/point"

DEFAULT_THRESHOLDS = {
    "very_hot_c": 35.0,
    "very_cold_c": 0.0,
    "very_windy_ms": 10.0,
    "very_wet_mm": 10.0,
    "very_uncomfortable_temp_c": 30.0,
    "very_uncomfortable_rh": 70.0
}

def fetch_power_daily(lat, lon, start, end, params):
    q = {
        "start": start,
        "end": end,
        "latitude": lat,
        "longitude": lon,
        "parameters": ",".join(params),
        "format": "JSON",
        "user": "WillItRain2025",
        "community": "RE"
}
    r = requests.get(POWER_BASE, params=q, timeout=30)
    if r.status_code != 200:
     raise Exception(f"NASA POWER API returned {r.status_code}: {r.text}")
    return r.json()


@app.route("/")
def home_page():
    return render_template("index.html")


@app.route("/api/query")
def api_query():
    try:
      lat = float(request.args.get("lat"))
      lon = float(request.args.get("lon"))
    except Exception as e:
      return jsonify({"error":"lat and lon required (float)", "detail": str(e)}), 400

    day = request.args.get("day")
    month = request.args.get("month")
    doy = request.args.get("dayofyear")

    if doy:
        dayofyear = int(doy)
        base_date = datetime.datetime(datetime.datetime.now().year,1,1) + datetime.timedelta(days=dayofyear-1)
        month = base_date.month
        day = base_date.day
    else:
     
       if (not month) or (not day):
        today = datetime.date.today()
        month = int(today.month)
        day = int(today.day)
       else:
        month = int(month)
        day = int(day)
 
    start_year = request.args.get("start_year", "2010")
    end_year = request.args.get("end_year", "2020")

    thresholds = DEFAULT_THRESHOLDS.copy()
    for k in thresholds.keys():
        if k in request.args:
            try:
                thresholds[k] = float(request.args.get(k))
            except:
                pass

    params = ["T2M","T2M_MIN","T2M_MAX","PRECTOT","WS2M","RH2M"]

    start = f"{start_year}0101"
    end = f"{end_year}1231"
    try:
     resp = fetch_power_daily(lat, lon, start, end, params)
    except Exception as e:
     app.logger.error(f"NASA POWER API failed: {str(e)}")
     return jsonify({"error":"Failed to fetch data from NASA POWER API", "detail": str(e)}), 500


    try:
        data = {}
        for p in params:
            data[p] = resp["properties"]["parameter"].get(p, {})
    except Exception as e:
        return jsonify({"error":"Unexpected API response format","detail":str(e),"raw":resp}), 500

    records = []
    for date_str, temp in data["T2M"].items():
      try:
        dt = datetime.datetime.strptime(date_str, "%Y%m%d").date()
      except Exception as e:
        app.logger.warning(f"Skipping invalid date {date_str}: {str(e)}")
        continue

      if dt.month == month and dt.day == day:
            rec = {"date": date_str, "t2m": temp}
            rec["t2m_max"] = data.get("T2M_MAX",{}).get(date_str)
            rec["t2m_min"] = data.get("T2M_MIN",{}).get(date_str)
            rec["precip_mm"] = data.get("PRECTOT",{}).get(date_str)
            rec["wind_ms"] = data.get("WS2M",{}).get(date_str)
            rec["rh"] = data.get("RH2M",{}).get(date_str)
            records.append(rec)

    if len(records) == 0:
        return jsonify({"error":"No historical records found for that date — try a broader year range or different day."}), 404

    n = len(records)
    counts = {
        "very_hot": 0,
        "very_cold": 0,
        "very_windy": 0,
        "very_wet": 0,
        "very_uncomfortable": 0
    }
    temps = []
    for r in records:
        if r.get("t2m_max") is not None and r["t2m_max"] >= thresholds["very_hot_c"]:
            counts["very_hot"] += 1
        if r.get("t2m_min") is not None and r["t2m_min"] <= thresholds["very_cold_c"]:
            counts["very_cold"] += 1
        if r.get("wind_ms") is not None and r["wind_ms"] >= thresholds["very_windy_ms"]:
            counts["very_windy"] += 1
        if r.get("precip_mm") is not None and r["precip_mm"] >= thresholds["very_wet_mm"]:
            counts["very_wet"] += 1
        if (r.get("t2m_max") is not None and r.get("rh") is not None and
            r["t2m_max"] >= thresholds["very_uncomfortable_temp_c"] and r["rh"] >= thresholds["very_uncomfortable_rh"]):
            counts["very_uncomfortable"] += 1
        if r.get("t2m") is not None:
            temps.append(r["t2m"])

    def pct(c): return round(100.0 * c / n, 1)

    result = {
        "location": {"lat": lat, "lon": lon},
        "query_date": {"month": int(month), "day": int(day)},
        "years_covered": {"start": int(start_year), "end": int(end_year)},
        "n_samples": n,
        "counts": counts,
        "probabilities_pct": {k: pct(v) for k,v in counts.items()},
        "stats": {
            "temp_mean_c": round(statistics.mean(temps),2) if temps else None,
            "temp_median_c": round(statistics.median(temps),2) if temps else None,
            "temp_min_c": round(min(temps),2) if temps else None,
            "temp_max_c": round(max(temps),2) if temps else None
        },
        "thresholds_used": thresholds
    }
    return jsonify(result)


@app.errorhandler(Exception)
def handle_exception(e):
    app.logger.error(f"Unhandled exception: {str(e)}")
    return jsonify({"error": "Internal server error", "detail": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)
