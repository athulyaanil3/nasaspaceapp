// main.js - frontend logic
const map = L.map('map').setView([20.5937,78.9629], 4);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors'}).addTo(map);

let pin = L.marker(map.getCenter(), {draggable:true}).addTo(map);

const latEl = document.getElementById('lat');
const lonEl = document.getElementById('lon');
const monthEl = document.getElementById('month');
const dayEl = document.getElementById('day');
const dropPinBtn = document.getElementById('dropPin');
const queryBtn = document.getElementById('queryBtn');
const resultsDiv = document.getElementById('results');

function updateInputsFromMarker(){
  const p = pin.getLatLng();
  latEl.value = p.lat.toFixed(4);
  lonEl.value = p.lng.toFixed(4);
}
pin.on('dragend', updateInputsFromMarker);
updateInputsFromMarker();

dropPinBtn.onclick = () => {
  const c = map.getCenter();
  pin.setLatLng(c);
  updateInputsFromMarker();
};

queryBtn.onclick = async () => {
  const lat = latEl.value;
  const lon = lonEl.value;
  const month = monthEl.value;
  const day = dayEl.value;
  if(!lat || !lon){ alert('Set latitude and longitude (drop pin)'); return; }
  resultsDiv.innerHTML = '<em>Querying historical data…</em>';
  try{
    const q = new URLSearchParams({lat, lon, month, day});
    const resp = await fetch('/api/query?' + q.toString());
    if(!resp.ok){ const text = await resp.text(); resultsDiv.innerHTML = '<pre style="color:salmon">'+text+'</pre>'; return; }
    const j = await resp.json();
    renderResults(j);
  }catch(err){
    resultsDiv.innerHTML = '<pre style="color:salmon">'+err.toString()+'</pre>';
  }
};

function renderResults(data){
  if(data.error){ resultsDiv.innerHTML = '<pre style="color:salmon">'+JSON.stringify(data,null,2)+'</pre>'; return; }
  const p = data.probabilities_pct;
  const stats = data.stats;
  resultsDiv.innerHTML = `
    <div>
      <div class="badge">Samples: ${data.n_samples} years</div>
      <div style="margin-top:8px">
        <div><strong>Very hot (max ≥ ${data.thresholds_used.very_hot_c}°C):</strong> <span class="prob">${p.very_hot}%</span></div>
        <div><strong>Very cold (min ≤ ${data.thresholds_used.very_cold_c}°C):</strong> <span class="prob">${p.very_cold}%</span></div>
        <div><strong>Very windy (≥ ${data.thresholds_used.very_windy_ms} m/s):</strong> <span class="prob">${p.very_windy}%</span></div>
        <div><strong>Very wet (precip ≥ ${data.thresholds_used.very_wet_mm} mm):</strong> <span class="prob">${p.very_wet}%</span></div>
        <div><strong>Very uncomfortable (t ≥ ${data.thresholds_used.very_uncomfortable_temp_c}°C & RH ≥ ${data.thresholds_used.very_uncomfortable_rh}%):</strong> <span class="prob">${p.very_uncomfortable}%</span></div>
      </div>
      <hr style="opacity:0.06;margin:10px 0">
      <div style="font-size:13px;color:#bcd">${stats.temp_mean_c}°C mean / median ${stats.temp_median_c}°C / range ${stats.temp_min_c}–${stats.temp_max_c}°C</div>
    </div>
  `;
}
