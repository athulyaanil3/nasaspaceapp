Will-It-Rain-On-My-Parade? — Historical Weather Odds App
========================================================

This is a starter full-stack web application (Flask backend + static frontend) that uses NASA's
POWER API (https://power.larc.nasa.gov/) to compute historical probabilities of specific
weather conditions ("very hot", "very cold", "very windy", "very wet", "very uncomfortable")
for a chosen location and day of year.

IMPORTANT:
- This project queries NASA POWER REST APIs. See documentation:
  https://power.larc.nasa.gov/docs/services/api/temporal/
- Some POWER endpoints have request limits. Consider caching results or registering/applying rate limits.
- The backend is intentionally simple for educational/demo purposes. For production, add robust error handling,
  authentication, rate-limiting, caching, and input validation.

Quick start (local):
1. Create a Python virtual environment:
   python -m venv venv
   source venv/bin/activate  # or venv\\Scripts\\activate on Windows
2. Install dependencies:
   pip install -r backend/requirements.txt
3. Run the Flask server:
   python backend/app.py
4. Open frontend/index.html in a browser (or serve it from a static server). The frontend will make requests
   to the backend (by default the backend listens on http://127.0.0.1:5000).

